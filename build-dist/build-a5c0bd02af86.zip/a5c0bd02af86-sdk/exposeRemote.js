
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/a5c0bd02af86-sdk/static/js/remoteEntry.js'
    